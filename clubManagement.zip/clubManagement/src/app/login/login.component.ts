import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParticipantService } from '../participant.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: any;
  constructor(private router: Router, private participantService: ParticipantService) {
    //this.user = { loginId: '', password: '' };
  }

  ngOnInit(): void {
  }

  validateUser(loginForm: any): void {
    if (loginForm.loginId === 'admin' && loginForm.password === 'admin') {
      this.participantService.setUserLoggedIn();
      this.router.navigate(['home']);
    }
    else  {
        this.getParticipantDetails(loginForm.loginId , loginForm.password);
    }
    
  }
  getParticipantDetails(loginId: any , password: any) {
       this.participantService.getParticipant(loginId,password).subscribe((data: any) => {
         console.log(loginId+" "+password) ; 
         this.user = data; 
         if(this.user === null)  {
           alert("Invalid Credentials");
         }
         else {
           alert("successful Login");
           this.participantService.setUserLoggedIn();
           this.router.navigate(['home']);
         }
        });
  }
  
}
