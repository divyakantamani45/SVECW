import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ParticipantService {

  isUserLogged: boolean;
  constructor(private httpClient: HttpClient) { 
    this.isUserLogged = false;
  }
  setUserLoggedIn(): any {
    this.isUserLogged=true;
  }
  setUserLoggedOut() {
    this.isUserLogged = false;
  }
  getUserLogged() {
    return this.isUserLogged;
  }

  register(regForm: any): any {
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/regParticipant',regForm);
  }

  getParticipant(loginId: any,password: any): any{
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getPatByUserPass/' + loginId +'/'+ password);
  }

}
