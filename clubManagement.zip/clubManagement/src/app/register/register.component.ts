import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParticipantService } from '../participant.service'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  participant: any;
  check: any;
  ngOnInit(): void {
  }
  constructor(private router: Router , private service: ParticipantService) { 
    this.participant={firstName:'',lastName: '',collegeId: '',branch: '',phone:'',email: '',loginId: '',password: ''};
  }
  registerUser(registerForm: any): void {
    this.service.register(registerForm).subscribe((result: any) => {
      console.log(result);
      this.check=result;
      if(this.check === 1)  {
        alert("Registration successful");
        this.router.navigate(['login']);
      }
      else {
        alert("Registration is not successful");
        this.router.navigate(['register']);
      }
      });
    console.log(registerForm);
  }
}
